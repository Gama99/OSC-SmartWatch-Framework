import argparse
import math, csv
from pythonosc import dispatcher
from pythonosc import osc_server
from pythonosc import udp_client
from python_volume_test import set_volume, get_volume

watchface_up = True
# watchface_up is true when the zval is negative
# ranges from -103 to 103

startZ = 2323
start_vol = 0
volume_mod = 5
start_valdir= -1
zmax = 0
first = True;
volgo = False
elsego = False
gofast = False
goslow = False
topper = False
# newstart = False;
def accelhandler(unused_addr, valx, valy, valz, mag, diff):
    global watchface_up, startZ, volume_mod, start_vol, triggeron, start_valdir, first, volgo
    global gofast, goslow, topper
    if first:
        print("press left or right")
        print("left else or right volume")
        first = False

    if not volgo:
        return

    if valz > 103 or valz < -103:
        return

    if not triggeron:
        startZ = valz 
        start_vol = get_volume()
        if valy <= 0:
            start_valdir = -1
        else:
            start_valdir = 1

    if triggeron:
        print("--------------")
        # if start_valdir == 1:
        if valy < 0:
            tehchange = volume_mod*(math.floor((-103-valz - (startZ+103))/10))
        else:
            tehchange = volume_mod*(math.floor((valz - startZ)/10))
        newvol = start_vol + tehchange
        if newvol < 0:
            newvol = 0
        if newvol > 99:
            # print('big')
            newvol = 99
        print(newvol)
        set_volume(newvol)


    if abs(valz < 10 and valx < -80):
        print("hand raised")

    # print(gofast)
    if gofast:
        if mag < 10:
            # goslow = True
            gofast = False
            triggeron = True
            client2.send_message("/togglepos", triggeron)
            # print("slow")
    else:
        if mag > 75:
            gofast = True
            # print("fast")
    # file1 = open('workingonotehrthings.csv', 'a', encoding='UTF8', newline='')
    # writer = csv.writer(file1)
    # data = [valx, valy, valz, mag, diff]
    # writer.writerow(data)   
    # file1.close()


    x=0
    # print('accel')
    # print(valx, valy, valz, mag, diff)

def multitest(unused_addr, valx, valy, valz):
    x=0
    # print(str(valx) + " " + str(valy) + " " + str(valz))

def rawhrthandler(unused_addr, arg):
    # print('raw heart')
    # print(arg)
    # print(str(arg))

    x=0
    # file1 = open("staticmovementRawHRM.txt", "a")  # append mode
    # file1.write(str(arg))
    # file1.close()

def justsendresponce(unused_addr, arg):
    print("14")
    global client2
    client2.send_message("/pyresponce", "tehMessage")

def printHello(unused_addr, arg):
    print(arg)

def hrmhandler(unused_addr, hrate, cert):
    x=0
    # print('hrm')
    # print(hrate, cert)

count = 0
amin =0
amax = 0

def maghandler(unused_addr, x,y,z, dx,dy,dz, heading):
    # print(x)
    x=0

    # file1 = open('blank.csv', 'a', encoding='UTF8', newline='')
    # writer = csv.writer(file1)
    # data = [x,y,z,dx,dy,dz, heading]
    # writer.writerow(data)   
    # file1.close()
    
    # print('mag')
    # X = 0
    # Y = 1
    # Z = 2
    # global count, amin, amax
    # count += 1
    # # The two axes which relate to heading, depends on orientation of the sensor
    # # Think Left & Right, Forwards and Back, ignoring Up and Down
    # AXES = Y, Z
    # if count == 1:
    #     amin = list((x,y,z))
    #     return
    # if count == 2:
    #     amax = list((x,y,z))
    #     return
    # mag = list((x,y,z))
    
    # Step through each uncalibrated X, Y & Z magnetic value and calibrate them the best we can
    # for i in range(3):
    #     v = mag[i]
    #     # If our current reading (mag) is less than our stored minimum reading (amin), then save a new minimum reading
    #     # ie save a new lowest possible value for our calibration of this axis
    #     if v < amin[i]:
    #         amin[i] = v
    #     # If our current reading (mag) is greater than our stored maximum reading (amax), then save a new maximum reading
    #     # ie save a new highest possible value for our calibration of this axis
    #     if v > amax[i]:
    #         amax[i] = v
        
    #     # Calibrate value by removing any offset when compared to the lowest reading seen for this axes
    #     mag[i] -= amin[i]
        
    #     # Scale value based on the higest range of values seen for this axes
    #     # Creates a calibrated value between 0 and 1 representing magnetic value
    #     try:
    #         mag[i] /= amax[i] - amin[i]
    #     except ZeroDivisionError:
    #         pass
    #     # Shift magnetic values to between -0.5 and 0.5 to enable the trig to work
    #     mag[i] -= 0.5

    # # Convert from Gauss values in the appropriate 2 axis to a heading in Radians using trig
    # # Note this does not compensate for tilt
    # heading2 = math.atan2(
    #         mag[AXES[0]],
    #         mag[AXES[1]])

    # # If heading is negative, convert to positive, 2 x pi is a full circle in Radians
    # if heading2 < 0:
    #     heading2 += 2 * math.pi
        
    # # Convert heading from Radians to Degrees
    # heading2 = math.degrees(heading2)
    # # Round heading to nearest full degree
    # heading2 = round(heading2)

    # # Note: Headings will not be correct until a full 360 deg calibration turn has been completed to generate amin and amax data
    # print("Heading: {}".format(heading2))
    # # print(heading)
    x=0

triggeron = False
def butt1handler(unused_addr, arg):
    print(arg)

def butt2handler(unused_addr, arg):
#   print(arg)
    global triggeron, goslow
    if not volgo:
        return
    if triggeron:
        triggeron = False
    else:
        triggeron = True

    # this was messing up the cancelling of the motion turning off thing part
    # triggeron = ~triggeron
    print("trig:", triggeron)

    client2.send_message("/togglepos", triggeron)


def butt3handler(unused_addr, arg):
  print(arg)

def butt4handler(unused_addr, arg):
    global volgo, elsego
    if not volgo and not elsego:
        
        print("else selected")
        elsego = True
    print(arg)

def butt5handler(unused_addr, arg):
    global volgo, elsego
    if not volgo and not elsego:
        print("volume selected")
        volgo = True
    print(arg)

client2 = -23;
args = -23
if __name__ == "__main__":
  # for recieving
  parser = argparse.ArgumentParser()
  parser.add_argument("--ip",
      default="127.0.0.1", help="The ip to listen on")
  parser.add_argument("--port",
      type=int, default=7500, help="The port to listen on")
  args = parser.parse_args()
  client = udp_client.SimpleUDPClient(args.ip, args.port)


  # to send back
  parser2 = argparse.ArgumentParser()
  parser2.add_argument("--ip",
      default="127.0.0.1", help="The ip to listen on")
  parser2.add_argument("--port",
      type=int, default=7400, help="The port to listen on")
  args2 = parser2.parse_args()
  client2 = udp_client.SimpleUDPClient(args2.ip, args2.port)

  dispatcher = dispatcher.Dispatcher()

  dispatcher.map("/accel", accelhandler)
  dispatcher.map("/rawheart", rawhrthandler)
  dispatcher.map("/hrm", hrmhandler)
  dispatcher.map("/mag", maghandler)
  dispatcher.map("/test1", printHello)
  dispatcher.map("/respc", justsendresponce)
  dispatcher.map("/butt1", butt1handler)
  dispatcher.map("/butt2", butt2handler)
  dispatcher.map("/butt3", butt3handler)
  dispatcher.map("/butt4", butt4handler)
  dispatcher.map("/butt5", butt5handler)


  server = osc_server.ThreadingOSCUDPServer(
      (args.ip, args.port), dispatcher)
  print("Serving on {}".format(server.server_address))
  server.serve_forever()