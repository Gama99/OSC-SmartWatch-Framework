import numpy as np 
import matplotlib.pyplot as plt
with open("staticmovementRawHRM.txt", "r+") as file1:
    lines = file1.readlines()

values = []
for line in lines:
    value = float(line.strip())
    values.append(value)
    # print(value)

average = sum(values)  / len(values)
mini = min(values)
maxi = max(values)
# print(mini)
# print(maxi)
count = 0
for each_val in values:
    if(abs(each_val) > 1):
        count += 1
# print(len(values))
# print(count)

n , bins ,patches = plt.hist(values, bins=30)
print(n)
print(bins)
for i in range(len(n)):
    if(n[i] > 0):
        print("value: ", str(bins[i]), " count: ", str(n[i]))
plt.show() 