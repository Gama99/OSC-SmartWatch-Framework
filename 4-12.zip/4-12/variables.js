// variable for holding the accelerometer data
var accel = {
    x: 0,
    y: 0,
    z: 0,
    mag: 0,
    diff: 0,
};

// variable for holding the raw heart rate data
var hrm_raw = 0;

// variable for holding the heart rate data
var hrm = {
    hrate: 0,
    cert: 0,
};
// oblect for the BLE connecition to the watch
var connection;

//counter for the number of time an invalid string is passed back from the watch
var error_count = 0;

// variable for holding the magnetometer data
var mag = {
    x: 0,
    y: 0,
    z: 0,
    dx: 0,
    dy: 0,
    dz: 0,
    heading: 0,
};