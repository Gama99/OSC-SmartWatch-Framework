
# pip install pythonosc


import argparse
import math
# import pythoncom 
from pythonosc import dispatcher
from pythonosc import osc_server
from pythonosc import udp_client
from python_volume_test import set_volume, get_volume




watchface_up = True
# watchface_up is true when the zval is negative
# ranges from -100 to 100

startZ = 2323
start_vol = 0
volume_mod = 3
# newstart = False;
def accelhandler(unused_addr, valx, valy, valz, mag, diff):
  # global watchface_up, startZ, volume_mod, start_vol, newstart
  # if newstart:
  #       # print(valz)
  #       startZ = valz 
  #       start_vol = get_volume()
  # # print(valz)

  # if not newstart:
  #   set_volume(volume_mod*(start_vol - math.floor((valz - startZ)/10)))
  print('accel')
  print(valx, valy, valz, mag, diff)

def multitest(unused_addr, valx, valy, valz):
    print(str(valx) + " " + str(valy) + " " + str(valz))

def rawhrthandler(unused_addr, arg):
    print('raw heart')
    print(arg)
    # print(str(arg))
    file1 = open("hrtDATA.txt", "a")  # append mode
    file1.write(str(arg))
    file1.close()

def justsendresponce(unused_addr, arg):
  # print("14")
  client2.send_message("/pyresponce", "tehMessage")

def printHello(unused_addr, arg):
  print(arg)

def hrmhandler(unused_addr, hrate, cert):
  print('hrm')
  print(hrate, cert)

def maghandler(unused_addr, x,y,z, dx,dy,dz, heading):
  print('mag')
  print(x,y,z, dx,dy,dz, heading)

triggeron = False
def butt1handler(unused_addr, arg):
  # print(arg)
  global triggeron
  triggeron = ~triggeron
  print(triggeron)
  client2.send_message("/togglepos", triggeron)

def butt2handler(unused_addr, arg):
  print(arg)

def butt3handler(unused_addr, arg):
  print(arg)

def butt4handler(unused_addr, arg):
  print(arg)

def butt5handler(unused_addr, arg):
  print(arg)

client2 = -23;
args = -23
if __name__ == "__main__":
  # for recieving
  parser = argparse.ArgumentParser()
  parser.add_argument("--ip",
      default="127.0.0.1", help="The ip to listen on")
  parser.add_argument("--port",
      type=int, default=7500, help="The port to listen on")
  args = parser.parse_args()
  client = udp_client.SimpleUDPClient(args.ip, args.port)


  # to send back
  parser2 = argparse.ArgumentParser()
  parser2.add_argument("--ip",
      default="127.0.0.1", help="The ip to listen on")
  parser2.add_argument("--port",
      type=int, default=7400, help="The port to listen on")
  args2 = parser2.parse_args()
  client2 = udp_client.SimpleUDPClient(args2.ip, args2.port)

  dispatcher = dispatcher.Dispatcher()

  dispatcher.map("/accel", accelhandler)
  dispatcher.map("/rawheart", rawhrthandler)
  dispatcher.map("/hrm", hrmhandler)
  dispatcher.map("/mag", maghandler)
  dispatcher.map("/test1", printHello)
  dispatcher.map("/respc", justsendresponce)
  dispatcher.map("/butt1", butt1handler)
  dispatcher.map("/butt2", butt2handler)
  dispatcher.map("/butt3", butt3handler)
  dispatcher.map("/butt4", butt4handler)
  dispatcher.map("/butt5", butt5handler)


  server = osc_server.ThreadingOSCUDPServer(
      (args.ip, args.port), dispatcher)
  print("Serving on {}".format(server.server_address))
  server.serve_forever()