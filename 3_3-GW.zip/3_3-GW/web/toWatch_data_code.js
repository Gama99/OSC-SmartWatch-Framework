var ACCEL_CODE = `
Bangle.on('accel',function(a) {
    var d = [
    "accel",
    Math.round(a.x*100),
    Math.round(a.y*100),
    Math.round(a.z*100),
    Math.round(a.diff*100),
    Math.round(a.mag*100),
    ];
    Bluetooth.println(d.join(","));
});
`;
var BTN1_CODE = `
setWatch(() => {
  setTimeout(()=>g.clear(), 1000);
  var b = ["B1", 1]
  Bluetooth.println(b.join(",")); 
}, BTN1, {repeat:true});
\n
 `;
 var BTN2_CODE = `
setWatch(() => {
  setTimeout(()=>g.clear(), 1000);
  var b = ["B2", 1]
  Bluetooth.println(b.join(",")); 
}, BTN2, {repeat:true});
\n
 `;
 var BTN3_CODE = `
setWatch(() => {
  setTimeout(()=>g.clear(), 1000);
  var b = ["B3", 1]
  Bluetooth.println(b.join(",")); 
}, BTN3, {repeat:true});
\n
 `;
 var BTN4_CODE = `
setWatch(() => {
  setTimeout(()=>g.clear(), 1000);
  var b = ["B4", 1]
  Bluetooth.println(b.join(",")); 
}, BTN4, {repeat:true});
\n
 `;
 var BTN5_CODE = `
setWatch(() => {
  setTimeout(()=>g.clear(), 1000);
  var b = ["B5", 1]
  Bluetooth.println(b.join(",")); 
}, BTN5, {repeat:true});
\n
 `;

var HRM_CODE = `
Bangle.setHRMPower(1);
Bangle.on('HRM', function(h) { 
    var w = [
    "Hrt",
    h.bpm,
    h.confidence,
    ];
    Bluetooth.println(w.join(","));
 });\n
 `;

var HRM_RAW_CODE = `
Bangle.ioWr(0x80,0); // turn HRM on
setInterval(() => {Bluetooth.println(['Hraw',analogRead(D29)])}, 100);

`;
var showcode = `
g.clear();
g.drawString('python responded to teh scale', 50, 100, true)

`;

var CLOCK_FACE = `
// position on screen
const X = 160, Y = 140;

function draw() {
  // work out how to display the current time
  var d = new Date();
  var h = d.getHours(), m = d.getMinutes();
  var time = (" "+h).substr(-2) + ":" + ("0"+m).substr(-2);
  // Reset the state of the graphics library
  g.reset();
  // draw the current time (4x size 7 segment)
  g.setFontAlign(1,1); // align right bottom
  g.drawString(time, X, Y, true /*clear background*/);
  // draw the seconds (2x size 7 segment)
  g.drawString(("0"+d.getSeconds()).substr(-2), X+30, Y, true /*clear background*/);
}

// Clear the screen once, at startup
g.clear();
// draw immediately at first
draw();
var secondInterval = setInterval(draw, 1000);

`;

var MUSIC_SCALE = `
Bangle.beep(200,207.65*8).then(
()=>Bangle.beep(200,220.00*8)).then(
()=>Bangle.beep(200,246.94*8)).then(
()=>Bangle.beep(200,261.63*8)).then(
()=>Bangle.beep(200,293.66*8)).then(
()=>Bangle.beep(200,329.63*8)).then(
()=>Bangle.beep(200,369.99*8)).then(
()=>Bangle.beep(200,392.00*8)).then(
()=>Bangle.beep(200,440.00*8));

`;


var MAG_CODE = `
 Bangle.setCompassPower(1)
 Bangle.on('mag', function(mag) {
  var m = [
    "mag",
    mag.x,
    mag.y,
    mag.z,
    mag.dx,
    mag.dy,
    mag.dz,
    mag.heading,
    ];
    Bluetooth.println(m.join(","));
 });\n
 `;

 var BUZZ_CODE = `
 Bangle.beep(200,6000)
 \n
 `;
