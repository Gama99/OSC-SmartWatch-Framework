#program i used for the raw data
    # just plots the data with x-axis being the numebr of data points

import matplotlib.pyplot as plt


data = []
with open('rawHRM_long.txt') as f:
    lines = f.readlines()
    for line in lines:
        line = line.strip()
        data.append(float(line))
print(data)
plt.plot(data)
plt.show()

#program i used for the processed data
    #HRMDATA_top.txt and HRMDATA.txt
    # they contain the data for calculated heart rate and the estimated certainty
# import matplotlib.pyplot as plt
# hrtRate = []
# cert = []
# with open('HRMDATA_top.txt') as f:
#     lines = f.readlines()
#     for line in lines:
#         line = line.strip()
#         # print (line)
#         hrtRate.append(float(line.split(',')[0]))
#         cert.append(float(line.split(',')[1]))

# # print(hrtRate)
# plt.plot(hrtRate)
# plt.show()