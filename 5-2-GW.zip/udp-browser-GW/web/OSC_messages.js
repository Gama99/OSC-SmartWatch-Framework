
var sayHello = function () {
    port.send({
    address: "/test1",
    args: ["hello"]
    });
};

var forHRM = function () {
    port.send({
    address: "/hrm",
    args: [hrm.hrate, hrm.cert]
    });
};

var forAccel = function () {
    port.send({
    address: "/accel",
    args: [accel.x, accel.y, accel.z, accel.mag, accel.diff]
    });
};

var forMAG = function () {
    port.send({
    address: "/mag",
    args: [mag.x, mag.y, mag.z,
        mag.dz,mag.dy,mag.dz,
        mag.heading,]
    });
};

var forRawHRM = function () {
    port.send({
    address: "/rawheart",
    args: [hrm_raw]
    });
};

var forButt1 = function () {
// console.log('tring to send butt')
    port.send({
    address: "/butt1",
    args: ["i pressed button 1 :)"]
    });
};
var forButt2 = function () {
// console.log('tring to send butt')
    port.send({
    address: "/butt2",
    args: ["i pressed button 2 :)"]
    });
};
var forButt3 = function () {
// console.log('tring to send butt')
    port.send({
    address: "/butt3",
    args: ["i pressed button 3 :)"]
    });
};
var forButt4 = function () {
// console.log('tring to send butt')
    port.send({
    address: "/butt4",
    args: ["i pressed button 4 :)"]
    });
};
var forButt5 = function () {
// console.log('tring to send butt')
    port.send({
    address: "/butt5",
    args: ["i pressed button 5 :)"]
    });
};

var checkForResponce = function () {
    console.log("checking for responce")
    port.send({
    address: "/respc",
    args: [1]
    });
};